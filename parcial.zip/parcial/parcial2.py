 print "MENU registros\n\n1)-Nuevo\n2)-Mostrar\n3)-Eliminar Registros"

 opcion = raw_input("Elige una Opcion: ")

 if opcion == "1";
    print "Nuevo regsitro\n"
    archivo = open("par2.csv","a")

    nombre = raw_input("ingrese Nombre del Cliente: ")
    telefono = raw_input("ingrese Numero de Telefono del Cliente: ")
    Departamento = raw_input("ingrese Departamento de Telefono del Cliente: ")
    Municipio = raw_input("ingrese Municipio de Telefono del Cliente: ")

    print "se ha guardado: " + nombre + ", con el tel: " + telefono
    archivo.write(nombre)
    archivo.write(",")
    archivo.write(telefono)
    archivo.write(",")
    archivo.write("\n")
    archivo.close()

  elif opcion == "2"
  print "Mostrar registro\n"
 archivo = open("par2.csv")

 print (archivo.read())
 archivo close ()

 elif opcion == "3"
 archivo = open("par2.csv","a")
 archivo.truncate()

 print "Registros Eliminados"
 archivo.close()



 else:
 print "debes elegir una opcion anterior"


